<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-06-01 13:38:11
         compiled from "C:\Apache24\htdocs\WebChat\view\error.html" */ ?>
<?php /*%%SmartyHeaderCode:6985556bfc9c32c615-26041595%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7b366a70ecc6ff94774d96dfd40313aedd1addd1' => 
    array (
      0 => 'C:\\Apache24\\htdocs\\WebChat\\view\\error.html',
      1 => 1433140689,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6985556bfc9c32c615-26041595',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_556bfc9c3a7bf4_84198914',
  'variables' => 
  array (
    'error' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_556bfc9c3a7bf4_84198914')) {function content_556bfc9c3a7bf4_84198914($_smarty_tpl) {?><div id="content">
    <div class="error"><?php echo $_smarty_tpl->tpl_vars['error']->value;?>
</div>
</div><?php }} ?>
