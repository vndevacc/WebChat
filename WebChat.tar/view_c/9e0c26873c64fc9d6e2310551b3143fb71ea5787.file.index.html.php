<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-05-15 12:53:24
         compiled from "C:\Users\HP 800\PhpstormProjects\WebChat\view\index.html" */ ?>
<?php /*%%SmartyHeaderCode:1065555404e3464d12-16457900%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9e0c26873c64fc9d6e2310551b3143fb71ea5787' => 
    array (
      0 => 'C:\\Users\\HP 800\\PhpstormProjects\\WebChat\\view\\index.html',
      1 => 1431584341,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1065555404e3464d12-16457900',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_555404e3467788_47960007',
  'variables' => 
  array (
    'name' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_555404e3467788_47960007')) {function content_555404e3467788_47960007($_smarty_tpl) {?>This is content <?php echo $_smarty_tpl->tpl_vars['name']->value;?>
<?php }} ?>
