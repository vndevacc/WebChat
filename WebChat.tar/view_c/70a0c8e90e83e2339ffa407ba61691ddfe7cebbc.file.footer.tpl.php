<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-05-20 13:58:27
         compiled from "C:\Users\HP 800\PhpstormProjects\WebChat\view\template\footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:32455540436055af4-95642236%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '70a0c8e90e83e2339ffa407ba61691ddfe7cebbc' => 
    array (
      0 => 'C:\\Users\\HP 800\\PhpstormProjects\\WebChat\\view\\template\\footer.tpl',
      1 => 1432105074,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '32455540436055af4-95642236',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_55540436057049_14194882',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55540436057049_14194882')) {function content_55540436057049_14194882($_smarty_tpl) {?><div id="footer" style="text-align: center;">
    Copyright &copy; 2015 by <a href="#">Cyobzu</a>
</div>

<div class="clear"></div>

<?php }} ?>
