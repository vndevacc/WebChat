<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-05-28 10:25:47
         compiled from "..\view\template\footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:23555555c57bd79c3c7-12877161%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e6f8c1baaf3126aa58ea7f0b71cbeff62ffe915d' => 
    array (
      0 => '..\\view\\template\\footer.tpl',
      1 => 1432603425,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '23555555c57bd79c3c7-12877161',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_555c57bd79d3c5_86020175',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_555c57bd79d3c5_86020175')) {function content_555c57bd79d3c5_86020175($_smarty_tpl) {?><div id="footer" style="text-align: center;">
    Copyright &copy; 2015 by <a href="#">Cybozu</a>
</div>

<div class="clear"></div>

<?php }} ?>
