<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-05-28 10:25:15
         compiled from "..\view\template\page.tpl" */ ?>
<?php /*%%SmartyHeaderCode:798555668a9b6b6770-39048697%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'be3171a984bdb4af31bb8ca88a52cc6ce0db843a' => 
    array (
      0 => '..\\view\\template\\page.tpl',
      1 => 1432178070,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '798555668a9b6b6770-39048697',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_55668a9b6bdc30_87220822',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55668a9b6bdc30_87220822')) {function content_55668a9b6bdc30_87220822($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("../../view/".((string)$_smarty_tpl->tpl_vars['content']->value).".html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<?php }} ?>
