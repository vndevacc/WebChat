<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-05-21 10:15:39
         compiled from "..\view\template\page.tpl" */ ?>
<?php /*%%SmartyHeaderCode:872555d4ddb5ba522-77853524%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '866381dac96641b65cef695d6c2f3b4935ef9e68' => 
    array (
      0 => '..\\view\\template\\page.tpl',
      1 => 1432178070,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '872555d4ddb5ba522-77853524',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_555d4ddb5e7a31_72468834',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_555d4ddb5e7a31_72468834')) {function content_555d4ddb5e7a31_72468834($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("../../view/".((string)$_smarty_tpl->tpl_vars['content']->value).".html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<?php }} ?>
