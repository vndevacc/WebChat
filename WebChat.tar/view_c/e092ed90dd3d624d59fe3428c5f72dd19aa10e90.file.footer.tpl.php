<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-05-26 08:23:47
         compiled from "..\view\template\footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:27618555d3435709450-93431711%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e092ed90dd3d624d59fe3428c5f72dd19aa10e90' => 
    array (
      0 => '..\\view\\template\\footer.tpl',
      1 => 1432603425,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '27618555d3435709450-93431711',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_555d343570a4f5_67177428',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_555d343570a4f5_67177428')) {function content_555d343570a4f5_67177428($_smarty_tpl) {?><div id="footer" style="text-align: center;">
    Copyright &copy; 2015 by <a href="#">Cybozu</a>
</div>

<div class="clear"></div>

<?php }} ?>
