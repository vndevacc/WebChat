<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-05-12 14:24:16
         compiled from "view\template.tpl" */ ?>
<?php /*%%SmartyHeaderCode:199205551aaa0e36293-05052302%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '58981ee6b2ca199003c368411c71e734af85cf87' => 
    array (
      0 => 'view\\template.tpl',
      1 => 1431415365,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '199205551aaa0e36293-05052302',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'name' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5551aaa0f1af21_22084356',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5551aaa0f1af21_22084356')) {function content_5551aaa0f1af21_22084356($_smarty_tpl) {?>
<html>
<head>
    <title>Smarty Test</title>
</head>
<body>
Hello <?php echo $_smarty_tpl->tpl_vars['name']->value;?>
!
</body>
</html><?php }} ?>
