<?php
/**
 * Created by PhpStorm.
 * User: HP 800
 * Date: 6/1/2015
 * Time: 9:06 AM
 */
apc_clear_cache();
?>